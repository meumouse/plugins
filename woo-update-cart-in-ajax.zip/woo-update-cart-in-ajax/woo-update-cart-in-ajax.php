<?php
/**
 * Plugin Name: Atualizar carrinho em AJAX para WooCommerce
 * Plugin URI: https://meumouse.com/
 * Description: Extensão que permite que o carrinho do WooCommerce seja atualizado automaticamente via AJAX.
 * Version: 1.0.0
 * Author: MeuMouse.com
 * Author URI: http://meumouse.com/
 * License: GPLv2
 * Text Domain: woo-update-cart-in-ajax
 * WC requires at least: 5.0
 * WC tested up to: 7.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Setup plugin constants
 *
 * @since  1.0.0
 * @return void
 */
define( 'WOO_UPDATE_CART_AJAX_PLUGIN_VERSION', '1.0.0' );
define( 'WOO_UPDATE_CART_AJAX_PLUGIN_FILE', __FILE__ );
define( 'WOO_UPDATE_CART_AJAX_PLUGIN_URL', plugins_url( basename( plugin_dir_path( WOO_UPDATE_CART_AJAX_PLUGIN_FILE ) ), basename( WOO_UPDATE_CART_AJAX_PLUGIN_FILE ) ) );
define( 'WOO_UPDATE_CART_AJAX_PLUGIN_DIR', dirname( __FILE__ ) );
define( 'WOO_UPDATE_CART_AJAX_PLUGIN_DIR_BASENAME', dirname( plugin_basename( __FILE__ ) ) );

/**
 * Include required files
 *
 * @since  1.0.0.
 * @return void.
 */
require  WOO_UPDATE_CART_AJAX_PLUGIN_DIR . '/includes/class-woo-update-cart-in-ajax-settings.php' ;
require_once  WOO_UPDATE_CART_AJAX_PLUGIN_DIR . '/includes/woo-update-cart-in-ajax-functions.php' ;

/**
 * Load textdomain
 */
function woo_update_cart_in_ajax_load_textdomain() {
	load_plugin_textdomain( 'woo-update-cart-in-ajax', false, WOO_UPDATE_CART_AJAX_PLUGIN_DIR_BASENAME . '/languages/' );
}
add_action( 'init', 'woo_update_cart_in_ajax_load_textdomain' );

/**
 * Plugin action links
 * 
 * @return array
 */
if ( is_admin() ) {
	add_filter( 'plugin_action_links_' . plugin_basename(__FILE__), 'woo_update_cart_in_ajax_action_links' );
}

function woo_update_cart_in_ajax_action_links( $action_links ) {
	$plugins_links = array(
		'<a href="' . admin_url( 'admin.php?page=wc-settings&tab=advanced&section=woo_update_cart_in_ajax' ) . '">' . __( 'Configurar', 'woo_custom_installments' ) . '</a>'
	);
	return array_merge( $plugins_links, $action_links );
}