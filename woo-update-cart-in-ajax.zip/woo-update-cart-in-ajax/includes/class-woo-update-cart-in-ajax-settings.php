<?php
/**
 * Admin menu settings
 *
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'Woo_Update_Cart_Ajax' ) ) {

	class Woo_Update_Cart_Ajax {

		public function __construct() {
			add_filter( 'woocommerce_get_sections_advanced', array( $this, 'add_advanced_settings_section_tab' ) );
			add_action( 'woocommerce_get_settings_advanced', array( $this, 'get_settings' ), 10, 2 );
		}

		public function add_advanced_settings_section_tab( $section ) {
			$section['woo_update_cart_in_ajax'] = __( 'Atualizar carrinho em AJAX', 'woo-update-cart-in-ajax' );

			return $section;
		}

		/**
		 * Get all the settings for this plugin for @see woocommerce_admin_fields() function.
		 *
		 * @return array Array of settings for @see woocommerce_admin_fields() function.
		 */
		public static function get_settings( $settings, $current_section ) {
			if ( 'woo_update_cart_in_ajax' == $current_section ) {

				$settings = array(
					'section_title'	=> array(
						'name'	=> __( 'Atualizar carrinho em AJAX', 'woo-update-cart-in-ajax' ),
						'type'	=> 'title',
						'desc'	=> __( 'Insira o atraso (em milissegundos) antes que o carrinho seja atualizado. 1 segundo = 1000 milissegundos.', 'woo-update-cart-in-ajax' ),
						'id'	=> 'woo_update_cart_in_ajax_section_title'
					),
					'delay'			=> array(
						'name'		=> __( 'Atraso', 'woo-update-cart-in-ajax' ),
						'type'		=> 'number',
						'desc'		=> __( 'Insira um atraso em milissegundos. Número de segundos para atrasar a atualização x 1000 = o número a ser inserido aqui.', 'woo-update-cart-in-ajax' ),
						'default'	=> 300,
						'id'		=> 'woo_update_cart_in_ajax_delay'
					),
					'section_end'	=> array(
						'type'		=> 'sectionend',
						'id'		=> 'woo_update_cart_in_ajax_section_end'
					)
				);
			}
			return apply_filters( 'woo_update_cart_in_ajax_settings', $settings );
		}
	}
	$GLOBAL['woo_update_cart_in_ajax'] = new Woo_Update_Cart_Ajax();
}