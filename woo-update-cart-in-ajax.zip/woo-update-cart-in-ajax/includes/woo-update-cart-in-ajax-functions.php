<?php

/**
 * Enqueue scripts
 *
 * @return void
 */
function woo_update_cart_in_ajax_scripts() {
    if ( is_cart() ) {
        // $suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';
        wp_enqueue_script( 'woo-update-cart-in-ajax', WOO_UPDATE_CART_AJAX_PLUGIN_URL . '/assets/js/woo-update-cart-in-ajax.js', array( 'jquery' ), WOO_UPDATE_CART_AJAX_PLUGIN_VERSION );
        wp_localize_script( 'woo-update-cart-in-ajax', 'update_vars', array(
            'delay'	=> get_option( 'woo_update_cart_in_ajax_delay' ) ? get_option( 'woo_update_cart_in_ajax_delay' ) : 300,
            'confirm' => __( 'Tem certeza de que deseja remover este item do carrinho?', 'woo-update-cart-in-ajax' ),
            'input_trigger' => apply_filters( 'woo_update_cart_in_ajax_input_trigger', '.qty' )
        ));
    }
}
add_action( 'wp_enqueue_scripts', 'woo_update_cart_in_ajax_scripts' );

/**
 * Enqueue styles
 *
 * @return void
 */
function woo_update_cart_in_ajax_styles() {
    if (is_cart() ) {
        wp_enqueue_style( 'woo-update-cart-in-ajax-styles', WOO_UPDATE_CART_AJAX_PLUGIN_URL . '/assets/css/style.css' );
    }
}
add_action( 'wp_enqueue_scripts', 'woo_update_cart_in_ajax_styles' );