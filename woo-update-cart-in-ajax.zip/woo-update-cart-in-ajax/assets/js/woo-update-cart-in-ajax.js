var countdown;

jQuery(document).on('change', update_vars.input_trigger, function() {
	var quantity = jQuery(this).val();
	clearTimeout( countdown );

	if (quantity == 0) {
		if (confirm(update_vars.confirm)) {
			// Running without a noticeable delay since the user confirmed their choice.
			countdown = setTimeout(woo_update_cart_in_ajax_trigger_button, 100);
		}
	} else {
		countdown = setTimeout(woo_update_cart_in_ajax_trigger_button, update_vars.delay);
	}
});

function woo_update_cart_in_ajax_trigger_button() {
	jQuery("[name='update_cart']").trigger("click");
}